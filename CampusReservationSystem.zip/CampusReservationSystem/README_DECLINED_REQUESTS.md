# Declined Requests Feature

This feature allows administrators to decline reservation requests with a reason. The declined requests are moved from the `request` table to a new `declined_request` table for record-keeping.

## Setup Instructions

1. Create the `declined_request` table in your database by running the SQL script:
   - Open phpMyAdmin
   - Select the `campus_db` database
   - Go to the SQL tab
   - Copy and paste the contents of `database_declined_requests.sql` and execute it

2. The feature includes:
   - A confirmation modal when declining a request
   - A second modal to enter the reason for declining
   - Backend processing to move the request to the declined_request table

## Files Modified/Added

- `src/Pages/Admin/Requests/adminRequests.jsx` - Updated with decline reason modal
- `src/Pages/Admin/Requests/adminRequests.css` - Added styles for the decline reason textarea
- `src/api/decline_request.php` - New API endpoint to handle declined requests
- `database_declined_requests.sql` - SQL script to create the declined_request table

## How It Works

1. Admin clicks "Decline" button on a request
2. Confirmation modal appears
3. After confirming, a second modal appears to enter the decline reason
4. Upon submission, the request is:
   - Copied to the declined_request table with the reason and admin info
   - Removed from the request table
   - Removed from the UI