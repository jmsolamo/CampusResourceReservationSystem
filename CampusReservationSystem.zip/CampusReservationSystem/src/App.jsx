import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import AuthContext from './context/AuthContext';
import EventContext from './context/EventContext';
import Login from './Pages/Login/login';
import Dashboard from './Pages/Dashboard/dashboard';
import AdminDashboard from './Pages/Admin/Dashboard/adminDashboard';
import AdminRequests from './Pages/Admin/Requests/adminRequests';
import AdminCreateEvent from './Pages/Admin/CreateEvent/adminCreateEvent';
import RequestEvent from './Pages/Request Event/requestEvent';
import ProtectedRoute from './components/ProtectedRoute';
import './App.css';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/admin/requests" element={<AdminRequests />} />
        <Route path="*" element={<div>Loading...</div>} />
      </Routes>
    </Router>
  );
}

export default App;