import React from 'react';
import 'boxicons/css/boxicons.min.css'; // Import Boxicons styles
import './settings.css'; // Your custom CSS file

function settings() {
    
}

export default settings;
