<?php
// Disable error display in response
ini_set('display_errors', 0);
error_reporting(E_ALL);

// CORS headers
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

try {
    // Only allow POST requests
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception("Method not allowed");
    }

    // Get JSON data from request
    $data = json_decode(file_get_contents("php://input"), true);

    if (!$data || !isset($data['id'])) {
        throw new Exception("Invalid JSON data or missing ID");
    }

    // Connect to DB
    $host = "localhost";
    $dbname = "campus_db"; 
    $dbuser = "root";
    $dbpass = "";

    $conn = new mysqli($host, $dbuser, $dbpass, $dbname);

    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    // Update reservation status to 'cancelled'
    $reservationId = $data['id'];
    $query = "UPDATE reservations SET status = 'cancelled' WHERE reservation_id = ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $reservationId);
    
    if (!$stmt->execute()) {
        throw new Exception("Error cancelling reservation: " . $stmt->error);
    }
    
    // Return success response
    echo json_encode([
        "success" => true,
        "message" => "Event cancelled successfully"
    ]);

    $conn->close();
} catch (Exception $e) {
    // Log error to server log
    error_log("Error in delete_event.php: " . $e->getMessage());
    
    // Return error as JSON
    echo json_encode([
        "success" => false,
        "message" => $e->getMessage()
    ]);
}
?>