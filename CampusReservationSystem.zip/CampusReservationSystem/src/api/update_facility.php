<?php
// Disable error display in response
ini_set('display_errors', 0);
error_reporting(E_ALL);

// Direct CORS headers first - must be before any output
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

try {
    // Only allow POST requests
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception("Method not allowed");
    }

    // Get JSON data from request
    $data = json_decode(file_get_contents("php://input"), true);

    if (!$data) {
        throw new Exception("Invalid JSON data");
    }

    // Validate required fields
    if (!isset($data['resource_id']) || empty($data['resource_id'])) {
        throw new Exception("Missing required field: resource_id");
    }

    // Connect to DB
    $host = "localhost";
    $dbname = "campus_db"; 
    $dbuser = "root";
    $dbpass = "";

    $conn = new mysqli($host, $dbuser, $dbpass, $dbname);

    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    // Set values for fields
    $resourceId = $data['resource_id'];
    $name = isset($data['name']) ? $data['name'] : null;
    $location = isset($data['location']) ? $data['location'] : null;
    $capacity = isset($data['capacity']) && !empty($data['capacity']) ? (int)$data['capacity'] : null;
    $description = isset($data['description']) ? $data['description'] : null;
    $requiresApproval = isset($data['requires_approval']) ? ($data['requires_approval'] ? 1 : 0) : null;

    // Build update query dynamically based on provided fields
    $updateFields = [];
    $params = [];
    $types = "";

    if ($name !== null) {
        $updateFields[] = "name = ?";
        $params[] = $name;
        $types .= "s";
    }

    if ($location !== null) {
        $updateFields[] = "location = ?";
        $params[] = $location;
        $types .= "s";
    }

    if ($capacity !== null) {
        $updateFields[] = "capacity = ?";
        $params[] = $capacity;
        $types .= "i";
    }

    if ($description !== null) {
        $updateFields[] = "description = ?";
        $params[] = $description;
        $types .= "s";
    }

    if ($requiresApproval !== null) {
        $updateFields[] = "requires_approval = ?";
        $params[] = $requiresApproval;
        $types .= "i";
    }

    // If no fields to update, return error
    if (empty($updateFields)) {
        throw new Exception("No fields to update");
    }

    // Create update query
    $query = "UPDATE resources SET " . implode(", ", $updateFields) . " WHERE resource_id = ?";
    $params[] = $resourceId;
    $types .= "i";

    // Prepare and execute statement
    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);

    if (!$stmt->execute()) {
        throw new Exception("Error updating facility: " . $stmt->error);
    }

    if ($stmt->affected_rows === 0) {
        throw new Exception("No changes made or facility not found");
    }

    $stmt->close();
    $conn->close();

    // Return success response
    echo json_encode([
        "success" => true,
        "message" => "Facility updated successfully"
    ]);

} catch (Exception $e) {
    // Log error to server log
    error_log("Error in update_facility.php: " . $e->getMessage());
    
    // Return error as JSON
    echo json_encode([
        "success" => false,
        "message" => $e->getMessage()
    ]);
}
?>