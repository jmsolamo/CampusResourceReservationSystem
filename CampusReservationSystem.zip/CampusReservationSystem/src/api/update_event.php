<?php
// Disable error display in response
ini_set('display_errors', 0);
error_reporting(E_ALL);

// CORS headers
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

try {
    // Only allow POST requests
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception("Method not allowed");
    }

    // Get JSON data from request
    $data = json_decode(file_get_contents("php://input"), true);

    if (!$data) {
        throw new Exception("Invalid JSON data");
    }

    // Connect to DB
    $host = "localhost";
    $dbname = "campus_db"; 
    $dbuser = "root";
    $dbpass = "";

    $conn = new mysqli($host, $dbuser, $dbpass, $dbname);

    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    // Extract data
    $reservationId = $data['id'];
    $eventName = $data['event_name'];
    $purpose = $data['purpose'];
    $startTime = $data['start_time'];
    $endTime = $data['end_time'];
    $resourceId = $data['resource_id'];

    // Update reservation
    $sql = "UPDATE reservations 
            SET event_name = ?, 
                purpose = ?, 
                start_time = ?, 
                end_time = ?, 
                resource_id = ?
            WHERE reservation_id = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssii", $eventName, $purpose, $startTime, $endTime, $resourceId, $reservationId);
    
    if (!$stmt->execute()) {
        throw new Exception("Error updating event: " . $stmt->error);
    }
    
    // Return success response
    echo json_encode([
        "success" => true,
        "message" => "Event updated successfully"
    ]);

    $conn->close();
} catch (Exception $e) {
    // Log error to server log
    error_log("Error in update_event.php: " . $e->getMessage());
    
    // Return error as JSON
    echo json_encode([
        "success" => false,
        "message" => $e->getMessage()
    ]);
}
?>