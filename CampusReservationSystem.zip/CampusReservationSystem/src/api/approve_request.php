<?php
// Disable error display in response to prevent breaking JSON
ini_set('display_errors', 0);
error_reporting(E_ALL);

// Log errors to file instead
ini_set('log_errors', 1);
ini_set('error_log', 'c:/xampp/htdocs/CampusReservationSystem/php_errors.log');

// CORS headers
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

try {
    // Only allow POST requests
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception("Method not allowed");
    }

    // Get JSON data from request
    $jsonInput = file_get_contents("php://input");
    error_log("Raw input: " . $jsonInput);
    
    $data = json_decode($jsonInput, true);

    if (!$data) {
        throw new Exception("Invalid JSON data: " . json_last_error_msg());
    }

    // Connect to DB
    $host = "localhost";
    $dbname = "campus_db"; 
    $dbuser = "root";
    $dbpass = "";

    $conn = new mysqli($host, $dbuser, $dbpass, $dbname);

    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    // Extract data
    $id = $data['id'] ?? null;
    $approvedBy = $data['approvedBy'] ?? 'Admin';
    
    if (!$id) {
        throw new Exception("Missing required field: id");
    }

    // Start transaction
    $conn->begin_transaction();

    try {
        // 1. Get the request data
        $query = "SELECT * FROM request WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            throw new Exception("Request not found");
        }
        
        $request = $result->fetch_assoc();
        $stmt->close();
        
        // 2. Insert into approved_request table
        // Create a copy of the request data and remove the ID to let MySQL auto-increment
        $fields = array_keys($request);
        $values = array_values($request);
        
        // Remove 'id' from fields and values to avoid primary key conflict
        $idIndex = array_search('id', $fields);
        if ($idIndex !== false) {
            unset($fields[$idIndex]);
            unset($values[$idIndex]);
            
            // Re-index arrays after removal
            $fields = array_values($fields);
            $values = array_values($values);
        }
        
        $placeholders = str_repeat('?,', count($fields) - 1) . '?';
        
        // Find the status index and update the value to 'approved'
        $statusIndex = array_search('status', $fields);
        if ($statusIndex !== false) {
            $values[$statusIndex] = 'approved';
        }
        
        $query = "INSERT INTO approved_request (" . implode(',', $fields) . ", approved_by) VALUES ($placeholders, ?)";
        $stmt = $conn->prepare($query);
        
        // Create types string for bind_param
        $types = str_repeat('s', count($values) + 1); // +1 for approved_by
        
        // Combine all parameters
        $params = array_merge([$types], $values, [$approvedBy]);
        
        // Call bind_param with dynamic parameters
        $stmt->bind_param(...$params);
        
        if (!$stmt->execute()) {
            throw new Exception("Error inserting into approved_request: " . $stmt->error);
        }
        $stmt->close();
        
        // Check if there's a date range to duplicate requests for
        if (!empty($request['date_need_from']) && !empty($request['date_need_until'])) {
            $startDate = new DateTime($request['date_need_from']);
            $endDate = new DateTime($request['date_need_until']);
            $interval = new DateInterval('P1D'); // 1 day interval
            
            // If start date is different from end date, create duplicate requests for each date in range
            if ($startDate < $endDate) {
                // Clone the original request data
                $duplicateRequest = $request;
                
                // Remove the ID field to avoid primary key conflicts
                unset($duplicateRequest['id']);
                
                // Start from the day after the first date
                $currentDate = clone $startDate;
                $currentDate->add($interval);
                
                // Loop through each date in the range
                while ($currentDate <= $endDate) {
                    // Update the date for this duplicate
                    $duplicateRequest['date_need_from'] = $currentDate->format('Y-m-d');
                    $duplicateRequest['date_need_until'] = $currentDate->format('Y-m-d');
                    
                    // Generate a new reference number for the duplicate
                    $duplicateRequest['reference_number'] = $request['reference_number'] . '-' . $currentDate->format('Ymd');
                    
                    // Insert the duplicate into approved_request
                    $dupFields = array_keys($duplicateRequest);
                    $dupPlaceholders = str_repeat('?,', count($dupFields) - 1) . '?';
                    $dupValues = array_values($duplicateRequest);
                    
                    // Find the status index and update the value to 'approved'
                    $dupStatusIndex = array_search('status', $dupFields);
                    if ($dupStatusIndex !== false) {
                        $dupValues[$dupStatusIndex] = 'approved';
                    }
                    
                    $dupQuery = "INSERT INTO approved_request (" . implode(',', $dupFields) . ", approved_by) VALUES ($dupPlaceholders, ?)";
                    $dupStmt = $conn->prepare($dupQuery);
                    
                    // Create types string for bind_param
                    $dupTypes = str_repeat('s', count($dupValues) + 1); // +1 for approved_by
                    
                    // Combine all parameters
                    $dupParams = array_merge([$dupTypes], $dupValues, [$approvedBy]);
                    
                    // Call bind_param with dynamic parameters
                    $dupStmt->bind_param(...$dupParams);
                    
                    if (!$dupStmt->execute()) {
                        error_log("Error duplicating request for date " . $currentDate->format('Y-m-d') . ": " . $dupStmt->error);
                    }
                    $dupStmt->close();
                    
                    // Move to next day
                    $currentDate->add($interval);
                }
            }
        }
        
        // 3. Delete from request table
        $query = "DELETE FROM request WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $id);
        
        if (!$stmt->execute()) {
            throw new Exception("Error deleting from request: " . $stmt->error);
        }
        $stmt->close();
        
        // Commit transaction
        $conn->commit();
        
        echo json_encode([
            "success" => true,
            "message" => "Request approved successfully"
        ]);
    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollback();
        throw $e;
    }
    
    $conn->close();
} catch (Exception $e) {
    // Log error to server log
    error_log("Error in approve_request.php: " . $e->getMessage());
    
    // Return error as JSON
    echo json_encode([
        "success" => false,
        "message" => $e->getMessage()
    ]);
}
?>