<?php
// Disable error display in response to prevent breaking JSON
ini_set('display_errors', 0);
error_reporting(E_ALL);

// Log errors to file instead
ini_set('log_errors', 1);
ini_set('error_log', 'c:/xampp/htdocs/CampusReservationSystem/php_errors.log');

// CORS headers
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

try {
    // Only allow POST requests
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception("Method not allowed");
    }

    // Get JSON data from request
    $jsonInput = file_get_contents("php://input");
    error_log("Raw input: " . $jsonInput);
    
    $data = json_decode($jsonInput, true);

    if (!$data) {
        throw new Exception("Invalid JSON data: " . json_last_error_msg());
    }

    // Connect to DB
    $host = "localhost";
    $dbname = "campus_db"; 
    $dbuser = "root";
    $dbpass = "";

    $conn = new mysqli($host, $dbuser, $dbpass, $dbname);

    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    // Extract data
    $id = $data['id'] ?? null;
    $reason = $data['reason'] ?? '';
    $rejectedBy = $data['rejectedBy'] ?? 'Admin';
    
    if (!$id || !$reason) {
        throw new Exception("Missing required fields: id and reason");
    }

    // Start transaction
    $conn->begin_transaction();

    try {
        // 1. Get the request data
        $query = "SELECT * FROM request WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            throw new Exception("Request not found");
        }
        
        $request = $result->fetch_assoc();
        $stmt->close();
        
        // 2. Insert into declined_request table with status explicitly set to 'declined'
        $fields = array_keys($request);
        $placeholders = str_repeat('?,', count($fields) - 1) . '?';
        $values = array_values($request);
        
        // Find the status index and update the value to 'declined'
        $statusIndex = array_search('status', $fields);
        if ($statusIndex !== false) {
            $values[$statusIndex] = 'declined';
        }
        
        $query = "INSERT INTO declined_request (" . implode(',', $fields) . ", reason, rejected_by) VALUES ($placeholders, ?, ?)";
        $stmt = $conn->prepare($query);
        
        // Create types string for bind_param
        $types = str_repeat('s', count($values) + 2); // +2 for reason and rejected_by
        
        // Combine all parameters
        $params = array_merge([$types], $values, [$reason, $rejectedBy]);
        
        // Call bind_param with dynamic parameters
        $stmt->bind_param(...$params);
        
        if (!$stmt->execute()) {
            throw new Exception("Error inserting into declined_request: " . $stmt->error);
        }
        $stmt->close();
        
        // 3. Delete from request table after copying to declined_request
        $query = "DELETE FROM request WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $id);
        
        if (!$stmt->execute()) {
            throw new Exception("Error deleting request: " . $stmt->error);
        }
        $stmt->close();
        
        // Commit transaction
        $conn->commit();
        
        echo json_encode([
            "success" => true,
            "message" => "Request declined successfully"
        ]);
    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollback();
        throw $e;
    }
    
    $conn->close();
} catch (Exception $e) {
    // Log error to server log
    error_log("Error in decline_request.php: " . $e->getMessage());
    
    // Return error as JSON
    echo json_encode([
        "success" => false,
        "message" => $e->getMessage()
    ]);
}
?>